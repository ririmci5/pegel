extends Node
## Loc (autoload) — multi bahasa. Pakai: Loc.t("key"). Bahasa tersimpan di SaveSystem ("lang").
## Urutan bahasa = paling banyak dipelajari + paling banyak penutur + negara non-Inggris.
## Teks yang belum ada di suatu bahasa otomatis jatuh ke Inggris.

signal changed

const LA := preload("res://scripts/lang_a.gd")
const LB := preload("res://scripts/lang_b.gd")

## [kode, nama asli bahasa]
const LANGS: Array = [
	["en", "English"], ["zh", "中文"], ["hi", "हिन्दी"], ["es", "Español"],
	["ar", "العربية"], ["fr", "Français"], ["bn", "বাংলা"], ["pt", "Português"],
	["ru", "Русский"], ["id", "Bahasa Indonesia"], ["ja", "日本語"], ["de", "Deutsch"],
	["ko", "한국어"], ["tr", "Türkçe"], ["vi", "Tiếng Việt"], ["it", "Italiano"],
]

const KEYS: Array = [
	"sub_burger",
	"sub_scroll",
	"playing",
	"round_over",
	"next_video",
	"burgers",
	"videos",
	"time_left",
	"swipe_s",
	"best",
	"lives_out",
	"time_up",
	"cap_burger",
	"cap_video",
	"new_record",
	"coins",
	"level_up",
	"play_again",
	"shop",
	"shop_upgrade",
	"mode_burger",
	"mode_scroll",
	"upgrades",
	"paper_skins",
	"others",
	"max",
	"coin_unit",
	"equipped",
	"equip",
	"gem",
	"vibration",
	"sound",
	"on",
	"off",
	"level",
	"language",
	"h_new",
	"h_bottom",
	"h_left",
	"h_right",
	"h_top",
	"h_send",
	"d_left",
	"d_right",
	"d_up",
	"d_down",
	"finger_1",
	"finger_2",
	"pop_plus",
	"pop_minus",
	"up_coin_value",
	"up_coin_value_d",
	"up_time_bonus",
	"up_time_bonus_d",
	"up_multiplier",
	"up_multiplier_d",
	"skin_white",
	"skin_sky",
	"skin_mint",
	"skin_pink",
	"skin_gold",
	"video_n",
	"music",
	"cap1",
	"cap2",
	"cap3",
	"cap4",
	"cap5",
	"gem_btn",
	"gem_note",
	"h_sides",
	"d_sides"
]

var lang: String = "en"
var _idx: Dictionary = {}
var _tables: Dictionary = {}


func _ready() -> void:
	for i in KEYS.size():
		_idx[KEYS[i]] = i
	_tables.merge(LA.DATA)
	_tables.merge(LB.DATA)
	var saved := str(SaveSystem.data.get("lang", ""))
	if saved == "" or not _tables.has(saved):
		saved = _detect()
	lang = saved


func _detect() -> String:
	var l := OS.get_locale_language()
	return l if _tables.has(l) else "en"


func t(key: String) -> String:
	var i: int = _idx.get(key, -1)
	if i < 0:
		return key
	var tbl: Array = _tables.get(lang, _tables["en"])
	var s: String = str(tbl[i])
	return s if s != "" else str(_tables["en"][i])


func is_rtl() -> bool:
	return lang == "ar"


func set_language(code: String) -> void:
	if not _tables.has(code) or code == lang:
		return
	lang = code
	SaveSystem.data["lang"] = code
	SaveSystem.save_game()
	changed.emit()
