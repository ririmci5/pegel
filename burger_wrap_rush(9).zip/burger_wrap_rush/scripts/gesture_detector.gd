extends RefCounted
## GestureDetector — mengubah event sentuhan mentah menjadi swipe (1 atau 2 jari, 4 arah).
## Mendukung multitouch. Swipe dievaluasi saat jari PERTAMA diangkat supaya terasa responsif.
## Untuk tes di desktop: tahan SHIFT saat drag mouse = swipe 2 jari.

signal swiped(fingers: int, dir: int)

enum Dir { LEFT, RIGHT, UP, DOWN, SIDES }  # SIDES = 2 jari bergerak berlawanan arah (kiri+kanan bersamaan)

const MIN_DIST := 55.0        # jarak minimum swipe (unit viewport 540 x 960)
const MAX_TIME_MS := 1500     # swipe yang terlalu lambat dianggap bukan swipe

## Opsional: Callable(event: InputEventScreenTouch) -> bool. False = sentuhan ini diabaikan
## (mis. dimulai di atas tombol).
var start_filter: Callable = Callable()

var _touches: Dictionary = {}   # index jari -> {"start": Vector2, "pos": Vector2}
var _ignored: Dictionary = {}
var _max_fingers: int = 0
var _t0: int = 0
var _consumed: bool = false


func reset() -> void:
	_touches.clear()
	_ignored.clear()
	_max_fingers = 0
	_consumed = false


func feed(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var te := event as InputEventScreenTouch
		if te.pressed:
			_on_press(te)
		else:
			_on_release(te)
	elif event is InputEventScreenDrag:
		var de := event as InputEventScreenDrag
		if _touches.has(de.index):
			_touches[de.index]["pos"] = de.position


func _on_press(te: InputEventScreenTouch) -> void:
	if start_filter.is_valid() and not bool(start_filter.call(te)):
		_ignored[te.index] = true
		return
	if _touches.is_empty():
		_max_fingers = 0
		_consumed = false
		_t0 = Time.get_ticks_msec()
	_touches[te.index] = {"start": te.position, "pos": te.position}
	_max_fingers = maxi(_max_fingers, _touches.size())


func _on_release(te: InputEventScreenTouch) -> void:
	if _ignored.has(te.index):
		_ignored.erase(te.index)
		return
	if not _touches.has(te.index):
		return
	_touches[te.index]["pos"] = te.position
	if not _consumed:
		_evaluate()
	_touches.erase(te.index)
	if _touches.is_empty():
		_consumed = false
		_max_fingers = 0


func _evaluate() -> void:
	# Lipat kiri+kanan: dua jari bergerak horizontal ke arah berlawanan (saling mendekat / menjauh).
	if _touches.size() == 2 and Time.get_ticks_msec() - _t0 <= MAX_TIME_MS:
		var ks := _touches.keys()
		var d0: Vector2 = (_touches[ks[0]]["pos"] as Vector2) - (_touches[ks[0]]["start"] as Vector2)
		var d1: Vector2 = (_touches[ks[1]]["pos"] as Vector2) - (_touches[ks[1]]["start"] as Vector2)
		if absf(d0.x) >= MIN_DIST * 0.7 and absf(d1.x) >= MIN_DIST * 0.7 \
				and absf(d0.x) > absf(d0.y) and absf(d1.x) > absf(d1.y) and d0.x * d1.x < 0.0:
			_consumed = true
			swiped.emit(2, Dir.SIDES)
			return
	# Tes di desktop: tahan CTRL + drag mouse = gerakan kiri+kanan.
	if _touches.size() == 1 and Input.is_key_pressed(KEY_CTRL):
		var k0 = _touches.keys()[0]
		var dd: Vector2 = (_touches[k0]["pos"] as Vector2) - (_touches[k0]["start"] as Vector2)
		if dd.length() >= MIN_DIST:
			_consumed = true
			swiped.emit(2, Dir.SIDES)
			return
	var sum := Vector2.ZERO
	for k in _touches.keys():
		sum += (_touches[k]["pos"] as Vector2) - (_touches[k]["start"] as Vector2)
	var d: Vector2 = sum / float(_touches.size())
	if d.length() < MIN_DIST:
		return
	if Time.get_ticks_msec() - _t0 > MAX_TIME_MS:
		return
	var fingers := 2 if (_max_fingers >= 2 or Input.is_key_pressed(KEY_SHIFT)) else 1
	var dir: int
	if absf(d.x) > absf(d.y):
		dir = Dir.RIGHT if d.x > 0.0 else Dir.LEFT
	else:
		dir = Dir.DOWN if d.y > 0.0 else Dir.UP
	_consumed = true
	swiped.emit(fingers, dir)
