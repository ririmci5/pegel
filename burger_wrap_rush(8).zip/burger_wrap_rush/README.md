# Burger Wrap Rush (Godot 4.3+)

Game clicker portrait: tap untuk membungkus burger, 20 detik per ronde.

## Cara main
Satu burger = 6 swipe. Panel petunjuk di atas layar selalu menunjukkan swipe berikutnya.

| Langkah | Gesture | Efek |
|---|---|---|
| 1. Burger baru | 1 jari, geser ke kiri | kertas + burger muncul dari kiri (burger pertama ronde sudah ada) |
| 2. Lipat bawah | 2 jari, geser ke atas | |
| 3a. Lipat kiri | 2 jari, geser ke kanan | |
| 3b. Lipat kanan | 1 jari, geser ke kiri | (3a dan 3b boleh urutan apa saja) |
| 4. Lipat atas | 2 jari, geser ke bawah | kertas menutup penuh, muncul stempel HUSH BURGER |
| 5. Kirim | 1 jari, geser ke kiri | burger pindah ke kiri = +1 burger |
| Kirim paksa | 2 jari, geser ke kiri | kalau belum selesai: nyawa -1 (nyawa ada 3) |

Gesture yang tidak berlaku saat itu hanya membuat kertas bergoyang (tanpa hukuman).
Ronde berakhir saat waktu habis atau nyawa habis.

**Mode Scroll**: swipe 1 jari ke atas = video berikutnya. Setiap video berbeda (animasi dibuat dari kode).
Pilih mode lewat tombol BURGER / SCROLL di layar awal.

**Tes di komputer**: mouse = 1 jari. Tahan **SHIFT** sambil drag = 2 jari.

## 3D
Burger (roti, patty, keju, selada, tomat, wijen) dan kertas dihitung di ruang 3D (kamera perspektif) lalu
digambar sebagai poligon 2D (`burger_canvas.gd` + `burger_item_3d.gd`). Tidak memakai renderer 3D GPU,
jadi aman di HP lama. Tiap lipatan kertas berdiri tegak di sisi burger lalu menutup bagian atas.

## Bahasa (16)
English, 中文, हिन्दी, Español, العربية, Français, বাংলা, Português, Русский, Bahasa Indonesia, 日本語, Deutsch,
한국어, Türkçe, Tiếng Việt, Italiano. Bahasa awal mengikuti bahasa HP (kalau tidak ada: English);
ganti lewat tombol kode bahasa (mis. "EN") di layar awal. Pilihan tersimpan.
Tambah bahasa baru: tambah satu daftar 70 teks di `lang_a.gd`/`lang_b.gd` (urutan = `Loc.KEYS`) dan satu baris di `Loc.LANGS`.
Font: memakai font sistem Android untuk huruf non-Latin (Mandarin, Jepang, Korea, Arab, Hindi, Bengali). Kalau ada HP yang
hurufnya kotak-kotak, masukkan font Noto Sans ke proyek (menambah beberapa MB ke APK).

## Struktur
```
burger_wrap_rush/
├── project.godot          <- file yang dibuka di Godot
├── icon.svg
├── scenes/main.tscn       <- satu-satunya scene (UI dibangun lewat kode)
└── scripts/
    ├── save_system.gd     (autoload) simpan/muat JSON lokal
    ├── game_manager.gd    (autoload) koin, XP, level, gem, upgrade, skin
    ├── timer_system.gd    hitung mundur ronde
    ├── gesture_detector.gd  swipe 1/2 jari, 4 arah (multitouch)
    ├── wrap_system.gd     aturan urutan lipatan + nyawa
    ├── gesture_hint.gd    panel petunjuk swipe berikutnya
    ├── scroll_video_view.gd  mode scroll video (video buatan kode)
    ├── burger_art.gd      gambar burger (dipakai bersama)
    ├── click_counter.gd   total swipe + Swipe/s
    ├── upgrade_shop.gd    layar toko
    ├── main.gd            UI + alur permainan
    ├── burger_view.gd     komposer: animasi lipat/masuk/keluar, pasang kamera
    ├── burger_item_3d.gd  geometri burger + kertas 4 lipatan (2 ruas berengsel) + stempel, digambar via proyeksi
    ├── burger_canvas.gd   kamera perspektif + penggambar poligon
    ├── burger_fx.gd       lapisan 2D: nyawa, partikel, teks melayang
    ├── loc.gd             (autoload) multi bahasa: Loc.t("key")
    ├── lang_a.gd / lang_b.gd  data terjemahan 16 bahasa
    ├── language_picker.gd layar pilih bahasa
    ├── table_view.gd      latar restoran + meja + alas kotak-kotak
    ├── sfx.gd             suara hasil sintesis kode
    └── ui_kit.gd          helper style/label/tombol
```

## Coba di komputer
1. Pasang Godot 4.3 atau lebih baru (versi Standard, bukan .NET): https://godotengine.org/download
2. Buka Godot -> **Import** -> pilih `project.godot` di folder ini -> **Import & Edit**.
3. Tekan **F5** (tombol Play di kanan atas). Klik mouse = tap.
4. Data tersimpan di folder `user://` Godot. Untuk reset: hapus `burger_wrap_save.json`
   (Project -> Open User Data Folder).

## Jadi APK
1. Godot: **Editor -> Manage Export Templates -> Download and Install**.
2. Pasang JDK 17 dan Android SDK (cara paling mudah: Android Studio, lalu SDK Manager:
   Android SDK Platform 34, Build-Tools 34.0.0, Command-line Tools, Platform-Tools).
   Angka versi persisnya: lihat dokumen "Exporting for Android" untuk versi Godot kamu.
3. **Editor -> Editor Settings -> Export -> Android**: isi *Java SDK Path* dan *Android SDK Path*.
4. Buat debug keystore (sekali saja), lalu isi path-nya di Editor Settings yang sama:
   ```
   keytool -keyalg RSA -genkeypair -alias androiddebugkey -keypass android -keystore debug.keystore -storepass android -dname "CN=Android Debug,O=Android,C=US" -validity 9999 -deststoretype pkcs12
   ```
5. **Project -> Export -> Add... -> Android**:
   - Package -> Unique Name: `com.namakamu.burgerwraprush`
   - Architectures: arm64-v8a DAN armeabi-v7a (banyak HP murah Android 9/10 memakai sistem 32-bit)
   - Permissions: centang **Vibrate**
   - Biarkan "Use Gradle Build" mati (APK lebih kecil, lebih simpel)
6. Colok HP (Opsi Pengembang -> USB debugging) lalu klik ikon Android di kanan atas editor
   (One-click deploy), atau **Export Project** -> simpan `.apk` -> kirim ke HP dan install.
7. Untuk rilis/Play Store: buat release keystore
   (`keytool -v -genkey -keystore burgerwrap-release.keystore -alias burgerwrap -keyalg RSA -keysize 2048 -validity 10000`),
   isi di preset Export (Release), dan **simpan keystore + passwordnya baik-baik**.

## Aset
Tidak ada aset eksternal. Burger, meja, kertas, partikel digambar lewat kode; suara disintesis kode;
font bawaan Godot. Ikon: `icon.svg` milik proyek ini. Kalau mau mempercantik (semuanya gratis):
- Model 3D & ikon: Kenney.nl ("Food Kit", "Game Icons") — CC0
- Suara: Kenney "Interface Sounds"/"Impact Sounds" (CC0), atau freesound.org (filter lisensi CC0)
- Font: Google Fonts "Lilita One" atau "Baloo 2" (SIL OFL)

## Ide pengembangan
Mode endless (waktu bertambah per combo), leaderboard (Google Play Games / server sendiri),
quest harian + login streak, pelanggan & pesanan (burger harus dibungkus sesuai permintaan),
skin burger/meja, power-up (waktu beku, 2x koin), efek suara musik latar, iklan reward opsional.

## Build APK otomatis lewat GitHub (tanpa install apa pun)
1. Upload isi folder ini ke repository GitHub (project.godot harus ada).
2. Buat file `.github/workflows/build-apk.yml` di repo dengan isi dari `build-apk.yml` di folder ini.
3. Buka tab **Actions**, tunggu build selesai, lalu download artifact `BurgerWrapRush-apk`.
APK-nya ditandatangani dengan debug key: cukup untuk dipasang di HP sendiri (bukan untuk Play Store).
