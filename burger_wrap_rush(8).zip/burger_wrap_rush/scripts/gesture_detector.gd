extends RefCounted
## GestureDetector — mengubah event sentuhan mentah menjadi swipe (1 atau 2 jari, 4 arah).
## Mendukung multitouch. Swipe dievaluasi saat jari PERTAMA diangkat supaya terasa responsif.
## Untuk tes di desktop: tahan SHIFT saat drag mouse = swipe 2 jari.

signal swiped(fingers: int, dir: int)

enum Dir { LEFT, RIGHT, UP, DOWN }

const MIN_DIST := 55.0        # jarak minimum swipe (unit viewport 540 x 960)
const MAX_TIME_MS := 1500     # swipe yang terlalu lambat dianggap bukan swipe

## Opsional: Callable(event: InputEventScreenTouch) -> bool. False = sentuhan ini diabaikan
## (mis. dimulai di atas tombol).
var start_filter: Callable = Callable()

var _touches: Dictionary = {}   # index jari -> {"start": Vector2, "pos": Vector2}
var _ignored: Dictionary = {}
var _max_fingers: int = 0
var _t0: int = 0
var _consumed: bool = false


func reset() -> void:
	_touches.clear()
	_ignored.clear()
	_max_fingers = 0
	_consumed = false


func feed(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var te := event as InputEventScreenTouch
		if te.pressed:
			_on_press(te)
		else:
			_on_release(te)
	elif event is InputEventScreenDrag:
		var de := event as InputEventScreenDrag
		if _touches.has(de.index):
			_touches[de.index]["pos"] = de.position


func _on_press(te: InputEventScreenTouch) -> void:
	if start_filter.is_valid() and not bool(start_filter.call(te)):
		_ignored[te.index] = true
		return
	if _touches.is_empty():
		_max_fingers = 0
		_consumed = false
		_t0 = Time.get_ticks_msec()
	_touches[te.index] = {"start": te.position, "pos": te.position}
	_max_fingers = maxi(_max_fingers, _touches.size())


func _on_release(te: InputEventScreenTouch) -> void:
	if _ignored.has(te.index):
		_ignored.erase(te.index)
		return
	if not _touches.has(te.index):
		return
	_touches[te.index]["pos"] = te.position
	if not _consumed:
		_evaluate()
	_touches.erase(te.index)
	if _touches.is_empty():
		_consumed = false
		_max_fingers = 0


func _evaluate() -> void:
	var sum := Vector2.ZERO
	for k in _touches.keys():
		sum += (_touches[k]["pos"] as Vector2) - (_touches[k]["start"] as Vector2)
	var d: Vector2 = sum / float(_touches.size())
	if d.length() < MIN_DIST:
		return
	if Time.get_ticks_msec() - _t0 > MAX_TIME_MS:
		return
	var fingers := 2 if (_max_fingers >= 2 or Input.is_key_pressed(KEY_SHIFT)) else 1
	var dir: int
	if absf(d.x) > absf(d.y):
		dir = Dir.RIGHT if d.x > 0.0 else Dir.LEFT
	else:
		dir = Dir.DOWN if d.y > 0.0 else Dir.UP
	_consumed = true
	swiped.emit(fingers, dir)
