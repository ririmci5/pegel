extends Control
## BurgerCanvas — kamera perspektif sederhana + penggambar item 3D ke canvas 2D.
## Tanpa renderer 3D GPU, jadi jalan di HP lama (hanya menggambar poligon 2D).

const TARGET := Vector3(0.0, 0.35, -0.04)
const DIST := 14.0

var items: Array = []        # digambar berurutan (yang pertama = paling belakang)
var cam_pos: Vector3 = Vector3.ZERO
var ppu: float = 100.0       # piksel per satuan dunia di titik target
var dist: float = DIST
var light: Vector3 = Vector3(0.4, 0.8, 0.45).normalized()   # arah KE lampu

var _right: Vector3
var _up: Vector3
var _fwd: Vector3
var _focal: float = 1000.0
var _center: Vector2 = Vector2(270, 400)


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func setup(center: Vector2, pixels_per_unit: float, pitch_deg: float) -> void:
	_center = center
	ppu = pixels_per_unit
	_focal = ppu * DIST
	var pitch := deg_to_rad(pitch_deg)
	cam_pos = TARGET + Vector3(0.0, sin(pitch), cos(pitch)) * DIST
	_fwd = (TARGET - cam_pos).normalized()
	_right = _fwd.cross(Vector3.UP).normalized()
	_up = _right.cross(_fwd)
	light = Basis.from_euler(Vector3(deg_to_rad(-58.0), deg_to_rad(28.0), 0.0)).z.normalized()
	queue_redraw()


## Titik dunia -> (x layar, y layar, kedalaman).
func proj(p: Vector3) -> Vector3:
	var v := p - cam_pos
	var zc := maxf(v.dot(_fwd), 0.5)
	return Vector3(_center.x + v.dot(_right) / zc * _focal, _center.y - v.dot(_up) / zc * _focal, zc)


func proj2(p: Vector3) -> Vector2:
	var s := proj(p)
	return Vector2(s.x, s.y)


func _draw() -> void:
	for it in items:
		it.draw(self, self)
