extends Control
## ScrollVideoView — mode "scroll video" ala TikTok. Mekanik: swipe 1 jari ke atas = video berikutnya.
## Setiap video BERBEDA: dibuat dari seed (template animasi, warna, jumlah objek, username,
## caption, lagu, jumlah like). Semuanya digambar lewat kode, jadi tidak ada file video
## (APK tetap kecil, tanpa isu hak cipta). Ganti dengan VideoStreamPlayer kalau mau video asli.

const UiKit := preload("res://scripts/ui_kit.gd")
const BurgerArt := preload("res://scripts/burger_art.gd")

const SLIDE_TIME := 0.28
const TEMPLATES := 8
const USERS: Array = ["hush.burger", "chef.rama", "nina.snack", "dapur.bekasi", "kang.wrap",
		"gudang.vibes", "mesin.mania", "asmr.lipat", "burger.kilat", "tim.swipe"]
const CAPTIONS: Array = ["cap1", "cap2", "cap3", "cap4", "cap5"]
const TAGS: Array = ["#fyp #hushburger", "#satisfying #asmr", "#burgerlover #wrap", "#viral #xyz",
		"#kuliner #bekasi", "#oddlysatisfying", "#fastfood #hush", "#trending #foryou"]
const SONGS: Array = ["suara asli - hush.burger", "lofi dapur - chef rama", "beat lipat 2026",
		"wrap it up (remix)", "crunchy sound ASMR", "swipe swipe swipe", "jingle burger kilat"]

var _index: int = 0
var _prev: int = -1
var _slide: float = 1.0
var _t: float = 0.0
var _tp: float = 0.0
var _wiggle: float = 0.0
var _cache: Dictionary = {}


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	clip_contents = true
	visible = false


func reset_session() -> void:
	_index = randi() % 1000
	_prev = -1
	_slide = 1.0
	_t = 0.0
	_cache.clear()
	queue_redraw()


## Geser ke video berikutnya (video lama naik keluar, video baru naik dari bawah).
func next_video() -> void:
	_prev = _index
	_tp = _t
	_index += 1
	_t = 0.0
	_slide = 0.0
	queue_redraw()


func wiggle() -> void:
	_wiggle = 1.0


func current_index() -> int:
	return _index


func _process(delta: float) -> void:
	if not is_visible_in_tree():
		return
	_t += delta
	_tp += delta
	if _slide < 1.0:
		_slide = minf(1.0, _slide + delta / SLIDE_TIME)
	if _wiggle > 0.0:
		_wiggle = maxf(0.0, _wiggle - delta * 4.0)
	queue_redraw()


# ------------------------------------------------------------------ Data per video
func _vid(i: int) -> Dictionary:
	if _cache.has(i):
		return _cache[i]
	var rng := RandomNumberGenerator.new()
	rng.seed = hash(i * 7919 + 17)
	var h := rng.randf()
	var likes := rng.randi_range(120, 980000)
	var v: Dictionary = {
		"tpl": (i * 3 + rng.randi_range(0, 1)) % TEMPLATES,   # video bersebelahan selalu beda template
		"c1": Color.from_hsv(h, 0.55, 0.32),
		"c2": Color.from_hsv(fmod(h + 0.12, 1.0), 0.7, 0.8),
		"acc": Color.from_hsv(fmod(h + 0.5, 1.0), 0.65, 1.0),
		"acc2": Color.from_hsv(fmod(h + 0.33, 1.0), 0.5, 1.0),
		"n": rng.randi_range(5, 10),
		"speed": rng.randf_range(0.8, 1.8),
		"seed": rng.randf() * 100.0,
		"user": "@%s%d" % [USERS[rng.randi() % USERS.size()], rng.randi_range(1, 99)],
		"caption": Loc.t(CAPTIONS[rng.randi() % CAPTIONS.size()]),
		"tags": TAGS[rng.randi() % TAGS.size()],
		"song": Loc.t("music") % SONGS[rng.randi() % SONGS.size()],
		"likes": _fmt(likes),
		"comments": _fmt(rng.randi_range(3, maxi(4, likes / 20))),
	}
	_cache[i] = v
	return v


func _fmt(n: int) -> String:
	if n >= 1000:
		return "%.1fK" % (n / 1000.0)
	return str(n)


# ------------------------------------------------------------------ Gambar
func _draw() -> void:
	var w := size.x
	var h := size.y
	var wob := sin(Time.get_ticks_msec() * 0.05) * 8.0 * _wiggle
	if _slide < 1.0:
		var e := 1.0 - pow(1.0 - _slide, 3.0)
		if _prev >= 0:
			_draw_video(_prev, _tp, Rect2(wob, -h * e, w, h))
		_draw_video(_index, _t, Rect2(wob, h * (1.0 - e), w, h))
	else:
		_draw_video(_index, _t, Rect2(wob, 0.0, w, h))


func _draw_video(i: int, t: float, rc: Rect2) -> void:
	var v := _vid(i)
	var c1: Color = v["c1"]
	var c2: Color = v["c2"]
	draw_polygon(PackedVector2Array([rc.position, Vector2(rc.end.x, rc.position.y), rc.end,
			Vector2(rc.position.x, rc.end.y)]), PackedColorArray([c1, c1, c2, c2]))
	_template(int(v["tpl"]), v, t, rc)
	_overlay(v, i, t, rc)


func _col(v: Dictionary, k: int) -> Color:
	return v["acc"] if k % 2 == 0 else v["acc2"]


func _template(tpl: int, v: Dictionary, t: float, rc: Rect2) -> void:
	var n: int = v["n"]
	var sp: float = v["speed"]
	var sd: float = v["seed"]
	var c := rc.position + rc.size * Vector2(0.5, 0.42)
	match tpl:
		0: # bola memantul
			for k in n:
				var rad := rc.size.x * (0.05 + 0.04 * fmod(float(k) * 0.37, 1.0))
				var x := rc.position.x + rc.size.x * (0.12 + 0.76 * fmod(float(k) * 0.381 + sd * 0.01, 1.0))
				var bounce := absf(sin(t * sp * 2.2 + float(k) * 1.7 + sd))
				var y := rc.end.y - rc.size.y * 0.25 - bounce * rc.size.y * 0.5
				draw_circle(Vector2(x, y), rad, _col(v, k))
				draw_circle(Vector2(x - rad * 0.3, y - rad * 0.3), rad * 0.25, Color(1, 1, 1, 0.5))
		1: # equalizer
			var bars := 12
			var bw := rc.size.x / float(bars + 1)
			for k in bars:
				var amp := 0.15 + 0.85 * absf(sin(t * sp * 3.0 + float(k) * 0.8 + sd))
				var bh := amp * rc.size.y * 0.42
				draw_rect(Rect2(rc.position.x + bw * (float(k) + 0.5) + bw * 0.1,
						rc.position.y + rc.size.y * 0.62 - bh, bw * 0.8, bh), _col(v, k))
		2: # poligon mengorbit
			for k in n:
				var a := t * sp * (0.6 + 0.1 * float(k)) + float(k) * TAU / float(n)
				var rr := rc.size.x * (0.15 + 0.3 * float(k) / float(n))
				var p := c + Vector2(cos(a), sin(a)) * rr
				var sides := 3 + (k % 4)
				var pts := PackedVector2Array()
				for s in sides:
					var th := a * 2.0 + TAU * float(s) / float(sides)
					pts.append(p + Vector2(cos(th), sin(th)) * rc.size.x * 0.06)
				draw_colored_polygon(pts, _col(v, k))
		3: # burger menari
			var bounce := absf(sin(t * sp * 2.5))
			var xf := Transform2D(sin(t * sp * 1.5) * 0.12, Vector2(1.0 + 0.06 * bounce, 1.0 - 0.06 * bounce),
					0.0, c + Vector2(0.0, -bounce * rc.size.y * 0.08))
			draw_set_transform_matrix(xf)
			BurgerArt.draw_burger(self, rc.size.x * 0.2, 1.0, true)
			draw_set_transform_matrix(Transform2D.IDENTITY)
			for k in 6:
				var a := t * sp + float(k) * TAU / 6.0
				draw_circle(c + Vector2(cos(a), sin(a) * 0.6) * rc.size.x * 0.32, 5.0, _col(v, k))
		4: # gelombang
			for layer in 4:
				var pts := PackedVector2Array()
				var base := rc.position.y + rc.size.y * (0.45 + 0.1 * float(layer))
				var amp := rc.size.y * (0.04 + 0.01 * float(layer))
				var steps := 14
				for s in steps + 1:
					pts.append(Vector2(rc.position.x + rc.size.x * float(s) / float(steps),
							base + sin(float(s) * 0.7 + t * sp * (1.0 + 0.3 * float(layer)) + float(layer) * 1.3 + sd) * amp))
				pts.append(rc.end)
				pts.append(Vector2(rc.position.x, rc.end.y))
				var col := _col(v, layer)
				col.a = 0.5 + 0.1 * float(layer)
				draw_colored_polygon(pts, col)
		5: # bintang jatuh
			for k in n * 2:
				var sx := rc.position.x + rc.size.x * fmod(float(k) * 0.6180339 + sd * 0.01, 1.0)
				var spd := (0.15 + 0.25 * fmod(float(k) * 0.37, 1.0)) * sp
				var sy := rc.position.y + fmod(t * spd + float(k) * 0.173, 1.0) * (rc.size.y + 40.0) - 20.0
				var rad := rc.size.x * (0.025 + 0.02 * fmod(float(k) * 0.29, 1.0))
				var pts := PackedVector2Array()
				for s in 10:
					var rr := rad if s % 2 == 0 else rad * 0.45
					var th := t * sp + TAU * float(s) / 10.0
					pts.append(Vector2(sx, sy) + Vector2(cos(th), sin(th)) * rr)
				draw_colored_polygon(pts, _col(v, k))
		6: # cincin membesar
			for k in 5:
				var f := fmod(t * 0.35 * sp + float(k) / 5.0, 1.0)
				var col := _col(v, k)
				col.a = 1.0 - f
				draw_arc(c, f * rc.size.x * 0.7, 0.0, TAU, 40, col, 1.0 + 6.0 * (1.0 - f))
			draw_circle(c, rc.size.x * (0.04 + 0.01 * sin(t * 6.0)), v["acc"])
		_: # terowongan persegi
			for k in 8:
				var f := fmod(t * 0.4 * sp + float(k) / 8.0, 1.0)
				var half := f * rc.size.x * 0.5
				var col := _col(v, k)
				col.a = 1.0 - f * 0.7
				var pts := PackedVector2Array()
				for s in 4:
					var th := t * 0.4 + PI * 0.25 + float(s) * PI * 0.5
					pts.append(c + Vector2(cos(th), sin(th)) * half * 1.414)
				pts.append(pts[0])
				draw_polyline(pts, col, 4.0)


func _txt(font: Font, text: String, pos: Vector2, fs: int, col: Color, width: float = -1.0,
		align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT) -> void:
	draw_string_outline(font, pos, text, align, width, fs, 5, Color(0, 0, 0, 0.7))
	draw_string(font, pos, text, align, width, fs, col)


func _heart(center: Vector2, s: float, col: Color) -> void:
	draw_circle(center + Vector2(-0.5 * s, -0.25 * s), 0.55 * s, col)
	draw_circle(center + Vector2(0.5 * s, -0.25 * s), 0.55 * s, col)
	draw_colored_polygon(PackedVector2Array([
		center + Vector2(-1.02 * s, -0.05 * s), center + Vector2(1.02 * s, -0.05 * s),
		center + Vector2(0.0, 1.0 * s)]), col)


func _overlay(v: Dictionary, i: int, t: float, rc: Rect2) -> void:
	var font := ThemeDB.fallback_font
	# gradasi gelap di bawah supaya teks terbaca
	var y0 := rc.position.y + rc.size.y * 0.55
	draw_polygon(PackedVector2Array([Vector2(rc.position.x, y0), Vector2(rc.end.x, y0), rc.end,
			Vector2(rc.position.x, rc.end.y)]),
			PackedColorArray([Color(0, 0, 0, 0), Color(0, 0, 0, 0), Color(0, 0, 0, 0.6), Color(0, 0, 0, 0.6)]))

	# nomor video (kiri atas, di bawah panel petunjuk)
	_txt(font, Loc.t("video_n") % i, rc.position + Vector2(14.0, 100.0), 14, Color(1, 1, 1, 0.85))

	# ikon kanan: like, komentar, bagikan
	var ix := rc.end.x - 38.0
	var iy := rc.position.y + rc.size.y * 0.5
	_heart(Vector2(ix, iy), 15.0, Color("ff3b5c"))
	_txt(font, str(v["likes"]), Vector2(ix - 30.0, iy + 36.0), 13, Color.WHITE, 60.0, HORIZONTAL_ALIGNMENT_CENTER)
	var cy := iy + 74.0
	draw_circle(Vector2(ix, cy), 14.0, Color.WHITE)
	draw_colored_polygon(PackedVector2Array([Vector2(ix - 8.0, cy + 8.0), Vector2(ix - 12.0, cy + 18.0), Vector2(ix + 2.0, cy + 11.0)]), Color.WHITE)
	_txt(font, str(v["comments"]), Vector2(ix - 30.0, cy + 36.0), 13, Color.WHITE, 60.0, HORIZONTAL_ALIGNMENT_CENTER)
	var sy := cy + 74.0
	draw_colored_polygon(PackedVector2Array([Vector2(ix - 14.0, sy - 2.0), Vector2(ix + 14.0, sy - 12.0),
			Vector2(ix + 6.0, sy + 14.0), Vector2(ix, sy + 3.0)]), Color.WHITE)

	# teks kiri bawah
	var bx := rc.position.x + 14.0
	var by := rc.end.y - 112.0
	_txt(font, str(v["user"]), Vector2(bx, by), 18, Color.WHITE)
	_txt(font, str(v["caption"]), Vector2(bx, by + 22.0), 15, Color.WHITE)
	_txt(font, str(v["tags"]), Vector2(bx, by + 42.0), 14, Color("bfe6ff"))
	_txt(font, str(v["song"]), Vector2(bx, by + 62.0), 13, Color(1, 1, 1, 0.85))

	# bar progres video
	draw_rect(Rect2(rc.position.x, rc.end.y - 4.0, rc.size.x, 4.0), Color(1, 1, 1, 0.25))
	draw_rect(Rect2(rc.position.x, rc.end.y - 4.0, rc.size.x * fmod(t / 8.0, 1.0), 4.0), Color.WHITE)
