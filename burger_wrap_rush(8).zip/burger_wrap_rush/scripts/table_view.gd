extends Control
## TableView — latar restoran: dinding ubin + garis merah diner, jendela, papan menu,
## meja kayu, dan alas makan kotak-kotak tempat kertas pembungkus diletakkan.
## Semua digambar lewat kode. Posisi alas mengikuti rumus burger di UiKit.

const UiKit := preload("res://scripts/ui_kit.gd")

const WALL := Color("f1dcb8")
const WALL_LINE := Color("e0c697")
const WOOD: Array = [Color("c8924f"), Color("bd8545"), Color("c48c4a")]
const SEAM := Color("7d4d22")

var view_offset: Vector2 = Vector2.ZERO:
	set(v):
		view_offset = v
		queue_redraw()


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	resized.connect(queue_redraw)


func _draw() -> void:
	var w := size.x
	var h := size.y
	var o := view_offset
	var wall_h := UiKit.HUD_TOP + 14.0
	var font := ThemeDB.fallback_font

	# ---------------- Dinding (digambar lebih besar supaya tak ada celah saat layar bergetar)
	draw_rect(Rect2(-60.0 + o.x, -60.0 + o.y, w + 120.0, wall_h + 60.0), WALL)
	var gx := -60.0
	while gx < w + 60.0:
		draw_line(Vector2(gx + o.x, -60.0 + o.y), Vector2(gx + o.x, wall_h + o.y), WALL_LINE, 1.0)
		gx += 38.0
	var gy := 0.0
	while gy < wall_h:
		draw_line(Vector2(-60.0 + o.x, gy + o.y), Vector2(w + 60.0 + o.x, gy + o.y), WALL_LINE, 1.0)
		gy += 38.0
	# garis merah ala diner
	draw_rect(Rect2(-60.0 + o.x, wall_h - 34.0 + o.y, w + 120.0, 14.0), Color("c8413b"))
	draw_rect(Rect2(-60.0 + o.x, wall_h - 20.0 + o.y, w + 120.0, 4.0), Color("fff3e0"))

	# jendela (kiri)
	var win := Rect2(w * 0.07 + o.x, 16.0 + o.y, 78.0, 62.0)
	draw_rect(win, Color("9fd3f0"))
	draw_rect(Rect2(win.position.x, win.position.y + win.size.y * 0.55, win.size.x, win.size.y * 0.45), Color("b7e3f7"))
	draw_rect(win, Color("fff7e8"), false, 4.0)
	draw_line(win.position + Vector2(win.size.x * 0.5, 0.0), win.position + Vector2(win.size.x * 0.5, win.size.y), Color("fff7e8"), 3.0)
	draw_line(win.position + Vector2(0.0, win.size.y * 0.5), win.position + Vector2(win.size.x, win.size.y * 0.5), Color("fff7e8"), 3.0)

	# papan menu (kanan)
	var menu := Rect2(w * 0.93 - 96.0 + o.x, 16.0 + o.y, 96.0, 64.0)
	draw_rect(menu, Color("2f2a2e"))
	draw_rect(menu, Color("8a5a2b"), false, 4.0)
	draw_string(font, menu.position + Vector2(0.0, 20.0), "MENU", HORIZONTAL_ALIGNMENT_CENTER, menu.size.x, 15, Color("fff3d6"))
	for i in 3:
		var ly := menu.position.y + 30.0 + float(i) * 11.0
		draw_line(Vector2(menu.position.x + 10.0, ly), Vector2(menu.position.x + 52.0 + float(i) * 8.0, ly), Color(1, 1, 1, 0.6), 2.0)
		draw_line(Vector2(menu.position.x + 66.0, ly), Vector2(menu.position.x + 86.0, ly), Color(1, 0.85, 0.4, 0.8), 2.0)

	# ---------------- Meja kayu
	var tx0 := -60.0 + o.x
	var ty0 := wall_h + o.y
	var plank := 54.0
	var i := 0
	var px := tx0
	while px < w + 60.0:
		draw_rect(Rect2(px, ty0, plank, h - wall_h + 60.0), WOOD[posmod(i, 3)])
		draw_line(Vector2(px, ty0), Vector2(px, h + 60.0), SEAM, 2.0)
		# serat kayu
		for g in 3:
			var gxx := px + 10.0 + float(g) * 15.0
			var gy0 := ty0 + 30.0 + fposmod(float(i * 97 + g * 53), 200.0)
			draw_line(Vector2(gxx, gy0), Vector2(gxx + 2.0, gy0 + 80.0), Color(0.45, 0.27, 0.1, 0.28), 2.0)
		px += plank
		i += 1
	# bayangan tepi belakang meja
	for k in 5:
		draw_rect(Rect2(tx0, ty0, w + 120.0, 4.0 * float(5 - k)), Color(0, 0, 0, 0.08))

	# ---------------- Alas makan kotak-kotak
	var c := UiKit.burger_center(size) + o
	var r := UiKit.burger_radius(size)
	var mat := Rect2(c.x - 2.45 * r, c.y - 2.15 * r, 4.9 * r, 4.2 * r)
	draw_rect(Rect2(mat.position + Vector2(5.0, 8.0), mat.size), Color(0, 0, 0, 0.22))
	var cell := 0.5 * r
	var rows := int(ceil(mat.size.y / cell))
	var cols := int(ceil(mat.size.x / cell))
	for ry in rows:
		for cx in cols:
			var col := Color("c0392b") if (ry + cx) % 2 == 0 else Color("f2c9a5")
			var rect := Rect2(mat.position + Vector2(float(cx) * cell, float(ry) * cell), Vector2(cell, cell))
			rect = rect.intersection(mat)
			if rect.size.x > 0.0 and rect.size.y > 0.0:
				draw_rect(rect, col)
	draw_rect(mat, Color("7a2018"), false, 4.0)

	# ---------------- Saus & tisu di tepi belakang meja (kiri & kanan)
	var by := wall_h + 4.0 + o.y
	# saus tomat
	draw_rect(Rect2(28.0 + o.x, by - 44.0, 22.0, 44.0), Color("d62828"))
	draw_rect(Rect2(33.0 + o.x, by - 56.0, 12.0, 14.0), Color("fff3e0"))
	draw_rect(Rect2(31.0 + o.x, by - 28.0, 16.0, 14.0), Color("fff3e0"))
	# mustard
	draw_rect(Rect2(58.0 + o.x, by - 38.0, 20.0, 38.0), Color("f4c430"))
	draw_rect(Rect2(63.0 + o.x, by - 50.0, 10.0, 14.0), Color("fff3e0"))
	# kotak tisu
	draw_rect(Rect2(w - 88.0 + o.x, by - 30.0, 58.0, 30.0), Color("e8e2d6"))
	draw_rect(Rect2(w - 88.0 + o.x, by - 30.0, 58.0, 30.0), Color("a8a090"), false, 2.0)
	draw_colored_polygon(PackedVector2Array([
		Vector2(w - 72.0 + o.x, by - 30.0), Vector2(w - 50.0 + o.x, by - 30.0), Vector2(w - 56.0 + o.x, by - 44.0)]), Color("ffffff"))

	# kilau hangat dari lampu
	draw_circle(Vector2(w * 0.5 + o.x, -20.0 + o.y), w * 0.55, Color(1.0, 0.92, 0.6, 0.07))
