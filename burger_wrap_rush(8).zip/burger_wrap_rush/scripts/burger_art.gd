extends RefCounted
## BurgerArt — gambar burger low-poly dari atas (sudut 3D). Dipakai BurgerView dan ScrollVideoView.
## Fungsi statis: `ci` adalah CanvasItem yang sedang berada di dalam _draw().

const UiKit := preload("res://scripts/ui_kit.gd")

const BUN_TOP := Color("eba94f")
const BUN_LIGHT := Color("f6c26b")
const BUN_SHADE := Color("c98530")
const BUN_BOTTOM := Color("c98530")
const BUN_BOTTOM_TOP := Color("dc9d44")
const PATTY_D := Color("4a2812")
const PATTY_L := Color("6b3a1e")
const LETTUCE := Color("6fd04a")
const TOMATO := Color("e5483c")
const CHEESE := Color("ffcf33")
const SEED := Color("fff3d6")
const SEEDS: Array = [Vector2(-0.45, -0.62), Vector2(-0.1, -0.82), Vector2(0.3, -0.7),
		Vector2(0.6, -0.45), Vector2(-0.65, -0.35), Vector2(0.0, -0.5),
		Vector2(0.35, -0.3), Vector2(-0.3, -0.25)]


static func al(col: Color, a: float) -> Color:
	return Color(col.r, col.g, col.b, col.a * a)


static func _ellipse(ci: CanvasItem, center: Vector2, rx: float, ry: float, col: Color, segs: int = 14) -> void:
	ci.draw_colored_polygon(UiKit.ellipse_points(center, rx, ry, segs), col)


## Titik (0,0) = pusat burger; r = radius. Lebar burger +-1.05 r, tinggi -0.9 r .. +0.8 r.
static func draw_burger(ci: CanvasItem, r: float, a: float = 1.0, shadow: bool = true) -> void:
	if shadow:
		_ellipse(ci, Vector2(0, 0.78 * r), 1.08 * r, 0.2 * r, Color(0, 0, 0, 0.25 * a), 16)

	# Roti bawah
	_ellipse(ci, Vector2(0, 0.60 * r), 0.95 * r, 0.2 * r, al(BUN_BOTTOM, a))
	ci.draw_rect(Rect2(-0.95 * r, 0.42 * r, 1.9 * r, 0.18 * r), al(BUN_BOTTOM, a))
	_ellipse(ci, Vector2(0, 0.42 * r), 0.95 * r, 0.2 * r, al(BUN_BOTTOM_TOP, a))

	# Patty
	_ellipse(ci, Vector2(0, 0.40 * r), 0.98 * r, 0.2 * r, al(PATTY_D, a))
	ci.draw_rect(Rect2(-0.98 * r, 0.26 * r, 1.96 * r, 0.14 * r), al(PATTY_D, a))
	_ellipse(ci, Vector2(0, 0.26 * r), 0.98 * r, 0.2 * r, al(PATTY_L, a))

	# Selada (bergerigi)
	var pts := PackedVector2Array()
	for i in 16:
		var th := TAU * float(i) / 16.0
		var k := 1.0 + 0.07 * sin(th * 7.0)
		pts.append(Vector2(cos(th) * 1.0 * r * k, 0.17 * r + sin(th) * 0.26 * r * k))
	ci.draw_colored_polygon(pts, al(LETTUCE, a))

	# Tomat & keju
	_ellipse(ci, Vector2(0, 0.12 * r), 0.9 * r, 0.2 * r, al(TOMATO, a))
	_ellipse(ci, Vector2(0, 0.07 * r), 0.98 * r, 0.2 * r, al(CHEESE, a), 4)
	ci.draw_colored_polygon(PackedVector2Array([
		Vector2(0.62 * r, 0.12 * r), Vector2(0.98 * r, 0.1 * r), Vector2(0.86 * r, 0.42 * r)]),
		al(CHEESE.darkened(0.1), a))

	# Roti atas (kubah) + facet low-poly
	var dome := PackedVector2Array()
	for i in 15:
		var th := PI + PI * float(i) / 14.0
		dome.append(Vector2(cos(th) * r, sin(th) * 0.9 * r))
	var full := PackedVector2Array(dome)
	for i in range(1, 8):
		var th2 := PI * float(i) / 8.0
		full.append(Vector2(cos(th2) * r, sin(th2) * 0.18 * r))
	ci.draw_colored_polygon(full, al(BUN_TOP, a))
	ci.draw_colored_polygon(PackedVector2Array([dome[2], dome[3], dome[4], dome[5], dome[6],
			Vector2(-0.1 * r, -0.3 * r)]), al(BUN_LIGHT, a))
	ci.draw_colored_polygon(PackedVector2Array([dome[10], dome[11], dome[12], dome[13], dome[14],
			Vector2(0.85 * r, 0.02 * r), Vector2(0.4 * r, -0.2 * r)]), al(BUN_SHADE, a))
	for s in SEEDS:
		_ellipse(ci, (s as Vector2) * r, 0.07 * r, 0.04 * r, al(SEED, a), 6)
