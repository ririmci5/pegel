extends Control
## GestureHint — panel kecil di atas area bermain: animasi "jari" menunjukkan swipe berikutnya.

const Gesture := preload("res://scripts/gesture_detector.gd")
const UiKit := preload("res://scripts/ui_kit.gd")

const DIR_KEYS: Array = ["d_left", "d_right", "d_up", "d_down"]

var _fingers: int = 1
var _dir: int = Gesture.Dir.LEFT
var _title: String = ""
var _t: float = 0.0
var _style: StyleBoxFlat


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_style = UiKit.style(Color(0.1, 0.08, 0.14, 0.85), 20, Color("ffd23f"), 3, 0)
	visible = false


func show_hint(fingers: int, dir: int, title: String) -> void:
	_fingers = fingers
	_dir = dir
	_title = title
	visible = true
	queue_redraw()


func hide_hint() -> void:
	visible = false


func _process(delta: float) -> void:
	if visible:
		_t += delta
		queue_redraw()


static func dir_vec(d: int) -> Vector2:
	match d:
		Gesture.Dir.LEFT:
			return Vector2.LEFT
		Gesture.Dir.RIGHT:
			return Vector2.RIGHT
		Gesture.Dir.UP:
			return Vector2.UP
	return Vector2.DOWN


func _draw() -> void:
	var panel := Rect2(size.x * 0.5 - 165.0, 12.0, 330.0, 62.0)
	draw_style_box(_style, panel)

	var v := dir_vec(_dir)
	var n := Vector2(-v.y, v.x)
	var c := panel.position + Vector2(52.0, 31.0)
	var a := c - v * 22.0
	var b := c + v * 22.0
	# jalur swipe + kepala panah
	draw_line(a, b, Color(1, 1, 1, 0.35), 3.0)
	draw_colored_polygon(PackedVector2Array([b + v * 9.0, b + n * 7.0, b - n * 7.0]), Color(1, 1, 1, 0.5))
	# "jari" bergerak sepanjang jalur
	var s := fmod(_t * 1.5, 1.0)
	var e := s * s * (3.0 - 2.0 * s)
	var f := a + (b - a) * e
	var col := Color(1.0, 0.82, 0.25, 1.0 - smoothstep(0.8, 1.0, s))
	if _fingers == 1:
		draw_circle(f, 9.0, col)
	else:
		draw_circle(f + n * 9.0, 8.0, col)
		draw_circle(f - n * 9.0, 8.0, col)

	var font := ThemeDB.fallback_font
	var tp := panel.position + Vector2(100.0, 28.0)
	var ttl := Loc.t(_title)
	var fs := _fit(font, ttl, 22, 220.0)
	draw_string_outline(font, tp, ttl, HORIZONTAL_ALIGNMENT_LEFT, 220.0, fs, 6, Color("2a1a10"))
	draw_string(font, tp, ttl, HORIZONTAL_ALIGNMENT_LEFT, 220.0, fs, Color.WHITE)
	var sub := "%s - %s" % [Loc.t("finger_%d" % _fingers), Loc.t(DIR_KEYS[_dir])]
	draw_string(font, panel.position + Vector2(100.0, 48.0), sub, HORIZONTAL_ALIGNMENT_LEFT, 220.0,
			_fit(font, sub, 14, 220.0), Color("ffd23f"))


## Kecilkan font sampai teks muat di lebar w (terjemahan bisa lebih panjang).
func _fit(font: Font, text: String, fs: int, w: float) -> int:
	while fs > 9 and font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x > w:
		fs -= 1
	return fs
