extends RefCounted
## BurgerItem3D — satu burger + kertas pembungkus dalam ruang 3D, digambar lewat proyeksi perspektif
## ke canvas 2D (tanpa renderer 3D GPU -> aman di HP lama). Urutan gambar memakai painter's algorithm.
## Satuan dunia: 1 = radius burger. Kertas rata di bidang y=0; burger duduk di atasnya.
## Tiap lipatan = dua ruas berengsel: ruas A berdiri tegak di sisi burger, ruas B menutup bagian atas.

const CW := 1.02       # setengah lebar inti kertas
const ZT := -1.0       # tepi inti sisi atas (jauh dari kamera)
const ZB := 0.92       # tepi inti sisi bawah (dekat kamera)
const LA := 0.84       # tinggi ruas tegak
const LB_BOTTOM := 1.04
const LB_TOP := 1.07
const LB_SIDE := 1.0
const TOP_Y := LA + 0.04
const YS := 0.72       # penyusutan tinggi burger
const SEG := 18

const FOLDS: Array = ["bottom", "left", "right", "top"]
# [nama, yaw, posisi engsel, panjang B, angkat, lapisan]
const DEFS: Array = [
	["bottom", 0.0, Vector3(0, 0.0, ZB), LB_BOTTOM, 0.000, 1],
	["left", -PI * 0.5, Vector3(-CW, 0.0, (ZB + ZT) * 0.5), LB_SIDE, 0.016, 2],
	["right", PI * 0.5, Vector3(CW, 0.0, (ZB + ZT) * 0.5), LB_SIDE, 0.016, 2],
	["top", PI, Vector3(0, 0.0, ZT), LB_TOP, 0.032, 3],
]

var paper_color: Color = Color.WHITE
var folds: Dictionary = {"bottom": 0.0, "left": 0.0, "right": 0.0, "top": 0.0}
var pos: Vector3 = Vector3.ZERO
var yaw: float = 0.0
var scl: Vector3 = Vector3.ONE


func _init(c: Color = Color.WHITE) -> void:
	paper_color = c


func set_paper_color(c: Color) -> void:
	paper_color = c


## fp: nilai 0..1 (boleh sedikit >1 untuk efek memantul) per lipatan.
func set_folds(fp: Dictionary) -> void:
	for k in FOLDS:
		folds[k] = float(fp[k])


func is_wrapped() -> bool:
	for k in FOLDS:
		if float(folds[k]) < 0.97:
			return false
	return true


# ------------------------------------------------------------------ Gambar
## cv: BurgerCanvas (punya proj(), light). faces dikumpulkan lalu digambar dari yang terjauh.
func draw(ci: CanvasItem, cv) -> void:
	var m := Transform3D(Basis(Vector3.UP, yaw).scaled(scl), pos)
	var faces: Array = []   # [key, PackedVector2Array, Color, outline(bool)]

	_shadow(m, cv, faces)
	_paper(m, cv, faces)
	if not is_wrapped():
		_burger(m, cv, faces)

	faces.sort_custom(func(a, b): return a[0] > b[0])
	for f in faces:
		var pts: PackedVector2Array = f[1]
		if _area(pts) < 1.5:
			continue
		ci.draw_colored_polygon(pts, f[2])
		if f[3]:
			var closed := pts.duplicate()
			closed.append(pts[0])
			ci.draw_polyline(closed, Color(0.25, 0.15, 0.1, 0.35), 1.4)

	if is_wrapped():
		_stamp(ci, m, cv)


func _area(p: PackedVector2Array) -> float:
	var a := 0.0
	for i in p.size():
		var q := p[(i + 1) % p.size()]
		a += p[i].x * q.y - q.x * p[i].y
	return absf(a) * 0.5


func _shade(n: Vector3, cv, lo: float = 0.62, gain: float = 0.45) -> float:
	return clampf(lo + gain * absf(n.normalized().dot(cv.light)), 0.0, 1.0)


func _tint(c: Color, k: float) -> Color:
	return Color(minf(c.r * k, 1.0), minf(c.g * k, 1.0), minf(c.b * k, 1.0), c.a)


func _shadow(m: Transform3D, cv, faces: Array) -> void:
	var pts := PackedVector2Array()
	for i in 28:
		var a := TAU * float(i) / 28.0
		pts.append(cv.proj2(m * Vector3(cos(a) * 1.55, -0.03, 0.05 + sin(a) * 1.4)))
	faces.append([9000.0, pts, Color(0, 0, 0, 0.2), false])


# ------------------------------------------------------------------ Kertas
func _quad(t: Transform3D, w: float, z0: float, z1: float, cv) -> Array:
	var hw := w * 0.5
	var corners := [Vector3(-hw, 0, z0), Vector3(hw, 0, z0), Vector3(hw, 0, z1), Vector3(-hw, 0, z1)]
	var pts := PackedVector2Array()
	var depth := 0.0
	var cy := 0.0
	for c in corners:
		var wp: Vector3 = t * c
		var s: Vector3 = cv.proj(wp)
		pts.append(Vector2(s.x, s.y))
		depth += s.z * 0.25
		cy += wp.y * 0.25
	return [pts, depth, cy, t.basis.y]


func _paper(m: Transform3D, cv, faces: Array) -> void:
	# inti kertas
	var core := _quad(m, 2.0 * CW, ZT, ZB, cv)
	faces.append([8000.0, core[0], _tint(paper_color, _shade(core[3], cv)), true])

	for d in DEFS:
		var name: String = d[0]
		var p: float = float(folds[name])
		var w: float = (2.0 * CW - 0.02) if (name == "bottom" or name == "top") else ((ZB - ZT) - 0.04)
		var pa := deg_to_rad(-90.0) * p
		var pbn := clampf((p - 0.25) / 0.75, 0.0, 1.06) if p > 0.0 else 0.0
		var pb := deg_to_rad(-90.0) * pbn
		var root := m * Transform3D(Basis(Vector3.UP, float(d[1])), Vector3(d[2]) + Vector3(0, float(d[4]), 0))
		var ta := root * Transform3D(Basis(Vector3.RIGHT, pa), Vector3.ZERO)
		var tb := ta * Transform3D(Basis(Vector3.RIGHT, pb), Vector3(0, 0, LA))
		var qa := _quad(ta, w, 0.0, LA, cv)
		var qb := _quad(tb, w, 0.0, float(d[3]), cv)
		faces.append([_key(qa, 0.0, 0), qa[0], _tint(paper_color, _shade(qa[3], cv)), true])
		faces.append([_key(qb, pbn, int(d[5])), qb[0], _tint(paper_color, _shade(qb[3], cv)), true])


## Kunci urut gambar: besar = digambar lebih dulu (jauh).
func _key(q: Array, bfold: float, layer: int) -> float:
	var cy: float = q[2]
	if cy < 0.15:
		return 4000.0 + float(q[1]) * 0.01          # rata di meja
	if layer > 0 and bfold > 0.5:
		return -100.0 - float(layer) * 10.0         # ruas B yang sudah menutup: di atas burger
	return float(q[1])


# ------------------------------------------------------------------ Burger
func _ring(m: Transform3D, cv, y: float, r: float, rx: float = 1.0) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in SEG:
		var a := TAU * float(i) / float(SEG)
		pts.append(cv.proj2(m * Vector3(cos(a) * r * rx, y * YS, sin(a) * r)))
	return pts


func _hull(a: PackedVector2Array, b: PackedVector2Array) -> PackedVector2Array:
	var all := PackedVector2Array()
	all.append_array(a)
	all.append_array(b)
	var h := Geometry2D.convex_hull(all)
	if h.size() > 1 and h[0] == h[h.size() - 1]:
		h.remove_at(h.size() - 1)
	return h


func _burger(m: Transform3D, cv, faces: Array) -> void:
	var key: float = float(cv.proj(m * Vector3(0, 0.3, 0)).z)
	var up_l: float = clampf(0.66 + 0.4 * cv.light.y, 0.0, 1.1)
	var bun := Color("e8a33c")
	# [y bawah, y atas, r bawah, r atas, warna]
	var parts: Array = [
		[0.0, 0.22, 0.78, 0.84, bun],
		[0.22, 0.40, 0.90, 0.90, Color("6b3a1f")],
		[0.44, 0.52, 0.93, 0.97, Color("5fc447")],
		[0.52, 0.60, 0.86, 0.86, Color("e8432f")],
	]
	var order := 0.0
	for p in parts:
		var rb := _ring(m, cv, float(p[0]), float(p[2]))
		var rt := _ring(m, cv, float(p[1]), float(p[3]))
		var col: Color = p[4]
		faces.append([key - order * 0.001, _hull(rb, rt), _tint(col, 0.74), false])
		faces.append([key - order * 0.001 - 0.0005, rt, _tint(col, up_l), false])
		order += 1.0
		if p[0] == 0.22:  # keju (berlian) di antara patty dan selada
			var cy := 0.44
			var d := PackedVector2Array()
			for c in [Vector3(0.99, cy * YS, 0), Vector3(0, cy * YS, 0.99), Vector3(-0.99, cy * YS, 0), Vector3(0, cy * YS, -0.99)]:
				d.append(cv.proj2(m * c))
			faces.append([key - order * 0.001, d, _tint(Color("ffcf3a"), up_l), false])
			order += 1.0

	# kubah roti: cincin bertingkat
	var prev := _ring(m, cv, 0.60, 0.88)
	var rings := 7
	for k in range(1, rings + 1):
		var t := float(k) / float(rings) * PI * 0.5
		var y := 0.60 + 0.44 * sin(t)
		var r := 0.88 * cos(t)
		var cur: PackedVector2Array
		if k == rings:
			cur = _ring(m, cv, y, 0.02)
		else:
			cur = _ring(m, cv, y, r)
		var shade := 0.74 + 0.26 * sin(t)
		faces.append([key - order * 0.001, _hull(prev, cur), _tint(bun, shade * up_l / 0.9), false])
		order += 1.0
		prev = cur

	# wijen
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	for i in 11:
		var th := rng.randf_range(0.12, 1.05)
		var ph := rng.randf_range(0.0, TAU)
		var lp := Vector3(0.88 * sin(th) * cos(ph), (0.60 + 0.44 * cos(th)) * YS, 0.88 * sin(th) * sin(ph))
		var n := (m.basis * Vector3(sin(th) * cos(ph), cos(th) * 1.2, sin(th) * sin(ph))).normalized()
		var s: Vector3 = cv.proj(m * lp)
		var to_cam: Vector3 = (cv.cam_pos - m * lp).normalized()
		if n.dot(to_cam) < 0.1:
			continue
		var sz: float = 0.085 * cv.ppu * clampf(float(cv.dist) / s.z, 0.5, 1.5)
		var seed_pts := PackedVector2Array()
		for j in 6:
			var a := TAU * float(j) / 6.0 + float(i)
			seed_pts.append(Vector2(s.x + cos(a) * sz, s.y + sin(a) * sz * 0.55))
		faces.append([key - order * 0.001 - 0.0002, seed_pts, Color("fff1c9"), false])


# ------------------------------------------------------------------ Stempel
func _stamp(ci: CanvasItem, m: Transform3D, cv) -> void:
	var c := Vector3(0, TOP_Y + 0.02, (ZB + ZT) * 0.5)
	var o: Vector3 = cv.proj(m * c)
	var ex: Vector3 = cv.proj(m * (c + Vector3(1, 0, 0)))
	var ez: Vector3 = cv.proj(m * (c + Vector3(0, 0, 1)))
	var k := 0.0034
	var xv := Vector2(ex.x - o.x, ex.y - o.y) * k
	var yv := Vector2(ez.x - o.x, ez.y - o.y) * k
	ci.draw_set_transform_matrix(Transform2D(xv, yv, Vector2(o.x, o.y)))
	var font := ThemeDB.fallback_font
	var col := Color("c0281f")
	var fs := 120
	for line in [["HUSH", -12.0], ["BURGER", 96.0]]:
		var w := font.get_string_size(str(line[0]), HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
		ci.draw_string(font, Vector2(-w * 0.5, float(line[1])), str(line[0]), HORIZONTAL_ALIGNMENT_LEFT, -1, fs, col)
	ci.draw_set_transform_matrix(Transform2D.IDENTITY)
