extends Control
## BurgerFX — lapisan 2D di atas burger 3D: nyawa (hati), partikel wijen/remah/konfeti, teks melayang.

const UiKit := preload("res://scripts/ui_kit.gd")
const BurgerArt := preload("res://scripts/burger_art.gd")

const MAX_PARTICLES := 160
const MAX_TEXTS := 8
const TEXT_LIFE := 0.8

var max_lives: int = 3
var lives: int = 3:
	set(v):
		lives = v
		queue_redraw()
var show_lives: bool = true

var _particles: Array = []
var _texts: Array = []
var _rng := RandomNumberGenerator.new()


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_rng.randomize()
	resized.connect(queue_redraw)


func clear() -> void:
	_particles.clear()
	_texts.clear()
	queue_redraw()


func popup(text: String, col: Color) -> void:
	if _texts.size() >= MAX_TEXTS:
		_texts.pop_front()
	var c := UiKit.burger_center(size)
	var r := UiKit.burger_radius(size)
	_texts.append({"p": Vector2(c.x, c.y - 0.2 * r), "t": 0.0, "text": text, "col": col})
	queue_redraw()



func burst(count: int) -> void:
	spawn(count, true)


func spawn(count: int, confetti: bool) -> void:
	var c := UiKit.burger_center(size)
	var r := UiKit.burger_radius(size)
	for i in count:
		if _particles.size() >= MAX_PARTICLES:
			_particles.pop_front()
		var kind := 2 if confetti else (0 if _rng.randf() < 0.6 else 1)
		var col: Color = BurgerArt.SEED
		if kind == 1:
			col = BurgerArt.BUN_SHADE
		elif kind == 2:
			var palette: Array = [Color("ff5d5d"), Color("ffd23f"), Color("6fe36f"), Color("5db8ff"), Color("ff8be0")]
			col = palette[_rng.randi() % palette.size()]
		var v := Vector2(_rng.randf_range(-260.0, 260.0), _rng.randf_range(-560.0, -200.0))
		if confetti:
			v *= 1.4
		_particles.append({
			"p": c + Vector2(_rng.randf_range(-0.8, 0.8) * r, _rng.randf_range(-0.6, 0.4) * r),
			"v": v,
			"life": _rng.randf_range(0.55, 0.95),
			"kind": kind,
			"col": col,
		})


func _process(delta: float) -> void:
	if not is_visible_in_tree():
		return
	var busy := false
	var i := _particles.size() - 1
	while i >= 0:
		var p: Dictionary = _particles[i]
		p["life"] = float(p["life"]) - delta
		if float(p["life"]) <= 0.0:
			_particles.remove_at(i)
		else:
			var v: Vector2 = p["v"]
			v.y += 900.0 * delta
			p["v"] = v
			p["p"] = (p["p"] as Vector2) + v * delta
		i -= 1
	if not _particles.is_empty():
		busy = true

	i = _texts.size() - 1
	while i >= 0:
		var t: Dictionary = _texts[i]
		t["t"] = float(t["t"]) + delta
		if float(t["t"]) >= TEXT_LIFE:
			_texts.remove_at(i)
		i -= 1
	if not _texts.is_empty():
		busy = true

	if busy:
		queue_redraw()

func _draw() -> void:
	# Nyawa
	if show_lives:
		for i in max_lives:
			var hc := Vector2(size.x * 0.5 + float(i - 1) * 46.0, 96.0)
			if i < lives:
				_heart(hc, 14.0, Color("2a1020"))
				_heart(hc, 11.5, Color("ff4d6d"))
			else:
				_heart(hc, 11.5, Color(0.35, 0.3, 0.42, 0.6))

	# Partikel wijen / remah / konfeti
	for p in _particles:
		var pos: Vector2 = p["p"]
		var col: Color = p["col"]
		col.a = clampf(float(p["life"]) / 0.25, 0.0, 1.0)
		match int(p["kind"]):
			0:
				draw_colored_polygon(PackedVector2Array([
					pos + Vector2(-5, 0), pos + Vector2(0, -3), pos + Vector2(5, 0), pos + Vector2(0, 3)]), col)
			1:
				draw_rect(Rect2(pos - Vector2(3, 3), Vector2(6, 6)), col)
			_:
				draw_rect(Rect2(pos - Vector2(5, 3), Vector2(10, 6)), col)

	# Teks melayang
	var font := ThemeDB.fallback_font
	for t in _texts:
		var k: float = float(t["t"]) / TEXT_LIFE
		var p: Vector2 = t["p"]
		p.y -= 90.0 * (1.0 - pow(1.0 - k, 2.0))
		var alpha := 1.0 - smoothstep(0.55, 1.0, k)
		var fs := int(lerpf(46.0, 34.0, minf(k * 6.0, 1.0)))
		var o := Vector2(p.x - 160.0, p.y)
		var col: Color = t["col"]
		draw_string_outline(font, o, str(t["text"]), HORIZONTAL_ALIGNMENT_CENTER, 320.0, fs, 8,
				Color(0.16, 0.1, 0.06, alpha))
		draw_string(font, o, str(t["text"]), HORIZONTAL_ALIGNMENT_CENTER, 320.0, fs,
				Color(col.r, col.g, col.b, alpha))



func _heart(center: Vector2, s: float, col: Color) -> void:
	draw_circle(center + Vector2(-0.5 * s, -0.25 * s), 0.55 * s, col)
	draw_circle(center + Vector2(0.5 * s, -0.25 * s), 0.55 * s, col)
	draw_colored_polygon(PackedVector2Array([
		center + Vector2(-1.02 * s, -0.05 * s), center + Vector2(1.02 * s, -0.05 * s),
		center + Vector2(0.0, 1.0 * s)]), col)
